self.__FONT_LOADER_MANIFEST={
  "pages": {},
  "app": {}
}